function S = dampS( t )
    A = 1;
    N = 8;
    alpha = 1/N;
    omega = 2 * pi * N;
    fi0 = 2 * pi / N;
    for i=1:length(t)
    e = exp(-alpha*t(i));
    S(i) = A*e*sin(omega*t(i)+fi0);
    end
end